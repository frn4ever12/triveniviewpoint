<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255'
            ],

            'unit_id'=>['required','exists:units,id'],
            'description'=>['nullable','string','max:255'],
            'group'=>['nullable','string','max:255'],
            'default_price'=>['nullable','numeric','min:0'],
            'multiple_unit'=>['nullable','boolean'],
            'opening_stock_quantity'=>['nullable','numeric','min:0'],
            'opening_stock_rate'=>['nullable','numeric','min:0'],
        ];
    }
}
