<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            UserSeeder::class,
            CategorySeeder::class,
            MenuItemSeeder::class,
            NepaliMenuItemSeeder::class,
            AboutSeeder::class,
            UnitSeeder::class,
            LabelSeeder::class,
            TableSeeder::class,
            ProductSeeder::class,
            RecipeSeeder::class,
        ]);
    }
}
